
from flask import Flask, request, jsonify
import os
import datetime

app = Flask(__name__)
os.makedirs("boost_profiles", exist_ok=True)

@app.route("/api/boost", methods=["POST"])
def boost():
    try:
        data = request.get_json()
        model = data.get("model", "Unknown")
        cpu = data.get("cpu", "Unknown")
        ram = data.get("ram", 0)
        log_entry = f"[{datetime.datetime.now()}] Model: {model}, CPU: {cpu}, RAM: {ram}MB\n"
        with open("boost_profiles/device_logs.txt", "a") as f:
            f.write(log_entry)
        script = f"""#!/system/bin/sh
# Boost config cho {model}
setprop power.scheduler_mode performance
settings put global sustained_performance_mode_enabled 1
settings put global force_gpu_rendering 1
setprop persist.sys.NEOKO.CPU_BOOST 1
svc power stayon true
"""
        if int(ram) >= 8000:
            script += "settings put global activity_manager_constants \"max_cached_processes=10\"\n"
        script += f"echo \"{model} boost xong lúc $(date)\" | curl -X POST http://localhost:5000/api/report -d @- --header \"Content-Type: text/plain\"\n"
        with open(f"boost_profiles/{model.replace(' ', '_')}_boost.sh", "w") as f:
            f.write(script)
        return script, 200, {'Content-Type': 'text/plain'}
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/report", methods=["POST"])
def report():
    content = request.data.decode("utf-8")
    with open("boost_profiles/results.txt", "a") as f:
        f.write(f"[{datetime.datetime.now()}] {content}\n")
    return "✅ Đã nhận kết quả", 200

@app.route("/api/status", methods=["GET"])
def status():
    return jsonify({"status": "NEOKO Server Online", "devices": os.listdir("boost_profiles")})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
